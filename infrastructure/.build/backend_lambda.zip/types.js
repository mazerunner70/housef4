"use strict";
/**
 * Transport-agnostic request/response shapes used by `dispatch` and adapters.
 */
Object.defineProperty(exports, "__esModule", { value: true });
