"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const lambda_1 = require("./adapters/lambda");
const handler = async (event, context) => (0, lambda_1.lambdaHandler)(event, context);
exports.handler = handler;
