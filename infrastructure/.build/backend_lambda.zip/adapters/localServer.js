"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.startLocalServer = startLocalServer;
const http = __importStar(require("node:http"));
const config_1 = require("../config");
const dispatch_1 = require("../dispatch");
const PORT = Number(process.env.PORT) || 3000;
function readBody(req) {
    return new Promise((resolve, reject) => {
        const chunks = [];
        req.on('data', (c) => {
            chunks.push(c);
        });
        req.on('end', () => {
            resolve(Buffer.concat(chunks).toString('utf8'));
        });
        req.on('error', reject);
    });
}
function incomingHeaders(req) {
    const out = {};
    for (const [k, v] of Object.entries(req.headers)) {
        out[k] = Array.isArray(v) ? v.join(', ') : v;
    }
    return out;
}
async function startLocalServer() {
    const cfg = (0, config_1.loadConfig)();
    console.log(`APP_ENV: ${cfg.appEnv} — listening on port ${PORT}`);
    const server = http.createServer(async (req, res) => {
        const url = req.url ?? '/';
        const method = req.method ?? 'GET';
        let rawBody = '';
        if (method !== 'GET' && method !== 'HEAD') {
            rawBody = await readBody(req);
        }
        const internal = {
            method,
            path: url,
            headers: incomingHeaders(req),
            rawBody,
        };
        const out = await (0, dispatch_1.dispatch)(internal);
        const headerPairs = { ...out.headers };
        res.writeHead(out.statusCode, headerPairs);
        res.end(JSON.stringify(out.body));
    });
    await new Promise((resolve, reject) => {
        server.listen(PORT, () => resolve());
        server.on('error', reject);
    });
    console.log(`Local API: http://localhost:${PORT}/api/health`);
    return server;
}
async function main() {
    await startLocalServer();
}
if (require.main === module) {
    main().catch((err) => {
        console.error(err);
        process.exitCode = 1;
    });
}
