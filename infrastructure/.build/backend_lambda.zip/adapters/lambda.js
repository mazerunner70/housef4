"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.lambdaHandler = lambdaHandler;
const config_1 = require("../config");
const dispatch_1 = require("../dispatch");
function jsonProxyResult(statusCode, body, extraHeaders = {}) {
    return {
        statusCode,
        headers: { 'Content-Type': 'application/json', ...extraHeaders },
        body: JSON.stringify(body),
    };
}
/**
 * Resolves Cognito subject (`sub`) from API Gateway request context.
 * Used in later steps for protected routes.
 */
function getAuthenticatedUserId(event) {
    const authorizer = event.requestContext?.authorizer;
    if (!authorizer)
        return undefined;
    const sub = authorizer.jwt?.claims?.sub ?? authorizer.claims?.sub;
    return typeof sub === 'string' && sub.length > 0 ? sub : undefined;
}
function lambdaHeaders(event) {
    const out = {};
    const h = event.headers;
    if (!h)
        return out;
    for (const [k, v] of Object.entries(h)) {
        if (typeof v === 'string')
            out[k.toLowerCase()] = v;
    }
    return out;
}
function getRawBody(event) {
    if (!event.body)
        return '';
    if (event.isBase64Encoded) {
        return Buffer.from(event.body, 'base64').toString('utf8');
    }
    return event.body;
}
function toInternalRequest(event) {
    return {
        method: event.httpMethod ?? 'GET',
        path: event.path ?? '/',
        headers: lambdaHeaders(event),
        rawBody: getRawBody(event),
        userId: getAuthenticatedUserId(event),
    };
}
async function lambdaHandler(event, context) {
    const cfg = (0, config_1.loadConfig)();
    console.log(`Request started: ${event.httpMethod} ${event.path} - RequestId: ${context.awsRequestId} - APP_ENV: ${cfg.appEnv}`);
    try {
        const internal = toInternalRequest(event);
        const res = await (0, dispatch_1.dispatch)(internal);
        return jsonProxyResult(res.statusCode, res.body, res.headers);
    }
    catch (err) {
        console.error(err);
        return jsonProxyResult(500, { error: 'Internal Server Error' });
    }
}
