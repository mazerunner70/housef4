"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getHealthPayload = getHealthPayload;
function getHealthPayload() {
    return { status: 'ok' };
}
