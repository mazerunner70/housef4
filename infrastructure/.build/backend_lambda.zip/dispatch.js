"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.dispatch = dispatch;
const health_1 = require("./handlers/health");
function isHealthPath(path) {
    const pathname = path.split('?')[0] ?? '';
    const segments = pathname.split('/').filter((s) => s.length > 0);
    const apiIdx = segments.indexOf('api');
    if (apiIdx < 0)
        return false;
    return (segments[apiIdx + 1] === 'health' && apiIdx + 2 === segments.length);
}
function jsonResponse(statusCode, body, extraHeaders = {}) {
    return {
        statusCode,
        headers: { 'Content-Type': 'application/json', ...extraHeaders },
        body,
    };
}
/**
 * Single application router. Lambda and local HTTP both call this with a normalized request.
 */
async function dispatch(req) {
    try {
        const method = req.method.toUpperCase();
        if (method === 'GET' && isHealthPath(req.path)) {
            return jsonResponse(200, (0, health_1.getHealthPayload)());
        }
        return jsonResponse(404, { error: 'Not Found' });
    }
    catch (err) {
        console.error(err);
        return jsonResponse(500, { error: 'Internal Server Error' });
    }
}
